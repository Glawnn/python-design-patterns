""" This is the init file for the pdp package. It imports the testA module. """

from .testa import test_a

__all__ = ["test_a"]

""" toto """

def test_a():
    """ toto """
    return 1